<?php
// Não commitar este arquivo!
$host = '192.185.211.125';
$db = 'monte814_zapfly';
$user = 'monte814_zapfly';
$pass = 'Wa76855867.';
