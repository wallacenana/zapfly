<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('dzhome2_render_restaurants_shortcode')) {
    function dzhome2_render_restaurants_shortcode($atts = [])
    {
        $atts = shortcode_atts([
            'title' => 'Restaurantes perto de voce',
            'description' => 'Digite seu endereco para ver as lojas disponiveis.',
            'search' => '',
            'location' => '',
            'category' => '',
            'limit' => 18
        ], $atts, 'digizap_home_2_restaurants');

        dzhome2_enqueue_assets();

        $limit = min(max(absint($atts['limit']), 1), 48);
        $queryCategory = '';
        if (isset($_GET['cat'])) {
            $queryCategory = function_exists('dzhome2_category_slug') ? dzhome2_category_slug((string) wp_unslash($_GET['cat'])) : sanitize_text_field((string) wp_unslash($_GET['cat']));
        } elseif (!empty($atts['category'])) {
            $queryCategory = function_exists('dzhome2_category_slug') ? dzhome2_category_slug((string) $atts['category']) : sanitize_text_field((string) $atts['category']);
        }

        $mapsKey = dzhome2_maps_key();
        $savedAddress = function_exists('dzhome2_read_address_cookie') ? dzhome2_read_address_cookie() : [];
        $initialLocation = trim((string) ($savedAddress['address'] ?? ''));
        $initialLocationLat = isset($savedAddress['lat']) ? (float) $savedAddress['lat'] : null;
        $initialLocationLng = isset($savedAddress['lng']) ? (float) $savedAddress['lng'] : null;
        $hasSelectedAddress = $initialLocation !== '';
        $initialAddressLabel = '';
        if ($hasSelectedAddress && function_exists('dzhome2_short_address')) {
            $initialAddressLabel = (string) (dzhome2_short_address($initialLocation)[0] ?? '');
        }

        $initialData = [
            'total' => 0,
            'categories' => [],
            'featuredStores' => [],
            'restaurants' => []
        ];

        if ($hasSelectedAddress) {
            $initialData = dzhome2_fetch_directory_data('', $queryCategory, $initialLocation, $limit, $initialLocationLat, $initialLocationLng);
        }

        $categoryLabel = '';
        if ($queryCategory !== '' && !empty($initialData['categories']) && is_array($initialData['categories'])) {
            foreach ($initialData['categories'] as $category) {
                $slug = function_exists('dzhome2_category_slug') ? dzhome2_category_slug((string) ($category['name'] ?? '')) : '';
                if ($slug === $queryCategory) {
                    $categoryLabel = (string) ($category['name'] ?? '');
                    break;
                }
            }
        }
        if ($categoryLabel === '' && $queryCategory !== '') {
            $categoryLabel = ucwords(str_replace('-', ' ', $queryCategory));
        }

        $pageTitle = $categoryLabel !== '' ? $categoryLabel : (string) $atts['title'];
        $pageDescription = $queryCategory !== ''
            ? 'Veja as lojas desta categoria para o seu endereco.'
            : (string) $atts['description'];

        ob_start();
        ?>
        <div
            class="dz-home2"
            data-dz-home2-root
            data-page="restaurants"
            data-mode="<?php echo esc_attr($hasSelectedAddress ? 'app' : 'landing'); ?>"
            data-category-slug="<?php echo esc_attr($queryCategory); ?>"
            data-api-base="<?php echo esc_attr(dzhome2_api_base()); ?>"
            data-home-url="<?php echo esc_attr(home_url('/')); ?>"
            data-restaurants-url="<?php echo esc_attr(dzhome2_restaurants_url()); ?>"
            data-login-url="<?php echo esc_attr(wp_login_url(home_url('/'))); ?>"
            data-register-url="<?php echo esc_attr(wp_registration_url()); ?>"
            data-blog-url="<?php echo esc_attr(dzhome2_blog_url()); ?>"
            data-storage-key="dz_home2_address"
            data-limit="<?php echo esc_attr($limit); ?>"
            data-maps-key="<?php echo esc_attr($mapsKey); ?>">
            <?php echo dzhome2_render_directory_header([
                'active' => 'restaurants',
                'homeUrl' => home_url('/'),
                'restaurantsUrl' => dzhome2_restaurants_url(),
                'blogUrl' => dzhome2_blog_url(),
                'loginUrl' => wp_login_url(home_url('/')),
                'registerUrl' => wp_registration_url(),
                'hasSelectedAddress' => $hasSelectedAddress,
                'initialAddressLabel' => $initialAddressLabel,
                'showBack' => true,
                'backUrl' => home_url('/'),
                'backLabel' => 'Voltar'
            ]); ?>

            <main class="dz-home2-main">
                <section class="dz-home2-landing" id="inicio" data-landing <?php echo $hasSelectedAddress ? 'hidden' : ''; ?>>
                    <div class="dz-home2-landing-grid">
                        <div class="dz-home2-landing-copy">
                            <span class="dz-home2-landing-badge">
                                <span aria-hidden="true">⚡</span>
                                <span>Cardapio digital inteligente</span>
                            </span>
                            <h1><?php echo esc_html($pageTitle); ?></h1>
                            <p><?php echo esc_html($pageDescription); ?></p>

                            <form class="dz-home2-address-form" data-address-form>
                                <input
                                    type="text"
                                    data-address-input
                                    placeholder="<?php echo esc_attr('Digite seu endereco completo'); ?>"
                                    autocomplete="off"
                                    spellcheck="false"
                                    inputmode="text">
                                <button type="submit" class="dz-home2-button dz-home2-button-primary" data-address-continue disabled>
                                    Continuar
                                </button>
                            </form>
                        </div>

                        <div class="dz-home2-landing-visual" aria-hidden="true">
                            <span class="dz-home2-visual-card dz-home2-visual-card-a"></span>
                            <span class="dz-home2-visual-card dz-home2-visual-card-b"></span>
                            <span class="dz-home2-visual-card dz-home2-visual-card-c"></span>
                            <span class="dz-home2-visual-badge"></span>
                            <span class="dz-home2-visual-ring"></span>
                        </div>
                    </div>
                </section>

                <section class="dz-home2-catalog" id="restaurantes" data-catalog <?php echo $hasSelectedAddress ? '' : 'hidden'; ?>>
                    <div class="dz-home2-catalog-head">
                        <div>
                            <a class="dz-home2-catalog-back" href="<?php echo esc_url(home_url('/')); ?>">Voltar</a>
                            <h2><?php echo esc_html($pageTitle); ?></h2>
                            <p><?php echo esc_html($pageDescription); ?></p>
                        </div>
                        <span class="dz-home2-catalog-count"><?php echo esc_html((string) absint($initialData['total'] ?? 0)); ?></span>
                    </div>

                    <div class="dz-home2-featured-track" data-featured-track>
                        <?php echo $hasSelectedAddress ? dzhome2_render_featured_cards($initialData['featuredStores'] ?? []) : ''; ?>
                    </div>

                    <div class="dz-home2-restaurants-grid" data-restaurants-grid>
                        <?php echo $hasSelectedAddress ? dzhome2_render_restaurant_cards($initialData['restaurants'] ?? []) : ''; ?>
                    </div>

                    <div class="dz-home2-empty-results" data-empty-results hidden>
                        Nenhum restaurante encontrado.
                    </div>
                </section>
            </main>
        </div>
        <?php
        return trim(ob_get_clean());
    }
}

add_shortcode('digizap_home_2_restaurants', 'dzhome2_render_restaurants_shortcode');
